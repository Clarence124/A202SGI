package com.example.swiftfix;


import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UpcomingList extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> serviceName, Dnt;
    Database2 DB;
    UpcomingAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_upcoming);
        DB =  new Database2(this);
        serviceName = new ArrayList<>();
        Dnt = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewUpcoming);
        adapter = new UpcomingAdapter(this,serviceName, Dnt);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displaydata();

    }

    private void displaydata() {

        Cursor cursor = DB.getdata();
        if(cursor.getCount()==0){
            Toast.makeText(UpcomingList.this, "No Data Exists", Toast.LENGTH_SHORT).show();
            return;
        }
else{
    while(cursor.moveToNext())
    {
        serviceName.add(cursor.getString(0));
        Dnt.add(cursor.getString(1));
    }
        }
    }

}
