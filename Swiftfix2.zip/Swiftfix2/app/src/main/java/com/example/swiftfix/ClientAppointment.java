package com.example.swiftfix;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.swiftfix.MainActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class ClientAppointment extends AppCompatActivity {

    // Declaration of UI elements
    private Button backBtn;
    private Spinner timeOfDaySpinner, serviceTypeSpinner;
    private EditText cInputPhoneNo, cInputAddress, cInputTime, cInputReason;
    private TextView cInputName, cShowInputDate;
    private ImageButton cInputDateBtn;
    private AutoCompleteTextView serviceProviderName;

    // Declaration of database helper variable
    private DatabaseHelper dbHelper;

    // Declaration of user input variables
    private String cInputTimeOfDay, cInputServiceType, formattedDate, formattedTime;
    private int cSelectHour, cSelectMinute;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_appointment);

        // Initialize UI elements
        backBtn = findViewById(R.id.backBtn);
        cInputName = findViewById(R.id.clientName);
        cInputPhoneNo = findViewById(R.id.clientPhoneNo);
        cInputAddress = findViewById(R.id.clientAddress);
        cShowInputDate = findViewById(R.id.dateDisplay);  // The text view for displaying the user selected date
        cInputDateBtn = findViewById(R.id.calendarBtn);  // The button for selecting the date via a date picker
        cInputTime = findViewById(R.id.appointmentTime);
        timeOfDaySpinner = findViewById(R.id.timeOfDaySpinner);
        serviceProviderName = findViewById(R.id.spName);
        cInputReason = findViewById(R.id.appointmentReason);
        serviceTypeSpinner = findViewById(R.id.serviceTypeSpinner);




        // Initialising the date picker
        // To get the current date of the device
        Calendar currentDate = Calendar.getInstance();
        int currentYear = currentDate.get(Calendar.YEAR);
        int currentMonth = currentDate.get(Calendar.MONTH);
        int currentDay = currentDate.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePicker = new DatePickerDialog(ClientAppointment.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // Converting the user selected date into a Date object
                Calendar selectedDate = new GregorianCalendar(year, month, day);
                Date date = selectedDate.getTime();

                // Formatting the date for display to integer day + string month
                SimpleDateFormat dateFormatter = new SimpleDateFormat("d MMM", Locale.getDefault());
                formattedDate = dateFormatter.format(date);

                // Displaying the formatted date
                cShowInputDate.setText(formattedDate);
            }
        }, currentYear, currentMonth, currentDay);



        // Initialising the time picker
        // To get the current time of the device
        Calendar currentTime = Calendar.getInstance();
        int currentHour = currentTime.get(Calendar.HOUR);
        int currentMinute = currentTime.get(Calendar.MINUTE);

        TimePickerDialog timePicker = new TimePickerDialog(ClientAppointment.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                // Passing the selected hour & minute into their variables to be inserted into the database
                cSelectHour = hour;
                cSelectMinute = minute;

                // Formatting the time for display & database insertion
                Calendar selectedTime = Calendar.getInstance();
                selectedTime.set(Calendar.HOUR, cSelectHour);     // using the same Calendar variable declared in the beginning of the onCreate() method
                selectedTime.set(Calendar.MINUTE, cSelectMinute); // for formatting the time
                Date selectedTimeCombine = selectedTime.getTime();

                SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm", Locale.getDefault());
                formattedTime = timeFormatter.format(selectedTimeCombine);

                // Displaying the selected time onto the EditText field
                cInputTime.setText(formattedTime);
            }
        }, currentHour, currentMinute, false);  // false sets the time to 12hr format




        // Time of Day Spinner (AM/PM)
        ArrayAdapter<CharSequence> TODAdapter = ArrayAdapter.createFromResource(ClientAppointment.this, R.array.timeOfDayDropdownStrings, android.R.layout.simple_spinner_item);
        TODAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timeOfDaySpinner.setAdapter(TODAdapter);
        timeOfDaySpinner.setPrompt(getString(R.string.timeOfDayHint)); // Spinner hint: AM/PM
        timeOfDaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int positionTime, long l) {
                // Retrieving the user selected value for AM/PM
                cInputTimeOfDay = (String) adapterView.getItemAtPosition(positionTime).toString(); // (String is to make sure the value retrieved is treated like a string)
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Alert user that this selection field is required
                Toast.makeText(ClientAppointment.this, "Please choose the time of the day", Toast.LENGTH_SHORT).show();
            }
        });




        // Service Type Spinner (Service/Maintenance)
        ArrayAdapter<CharSequence> serviceTypeAdapter = ArrayAdapter.createFromResource(ClientAppointment.this, R.array.serviceTypeDropdownStrings, android.R.layout.simple_spinner_item);
        serviceTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        serviceTypeSpinner.setAdapter(serviceTypeAdapter);
        serviceTypeSpinner.setPrompt(getString(R.string.serviceTypeHint));
        serviceTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int positionService, long l) {
                // Retrieving the user selected value for service type
                cInputServiceType = (String) adapterView.getItemAtPosition(positionService).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Alerting user that this selection field is required
                Toast.makeText(ClientAppointment.this, "Please choose service type", Toast.LENGTH_SHORT).show();
            }
        });





        // onClickListeners are set after initialising the date & time pickers so they're already generated before calling them out

        // For populating the name, phone, & address fields with user data
        String username = getIntent().getStringExtra("username"); // username retrieved from Intent
        String userType = getIntent().getStringExtra("userType"); // userType retrieved from Intent


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ClientAppointment.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("userType", userType);
                startActivity(intent);
            }
        });

        // Setting the onClickListener for the date picker
        cInputDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Display date picker when user clicks on calendar button
                datePicker.show();
            }
        });

        // Setting the onClickListener for the time picker
        cInputTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Display time picker when user clicks on 'cInputTime' EditText field
                timePicker.show();
            }
        });




        // Initialize the database helper
        dbHelper = new DatabaseHelper(ClientAppointment.this);


        Cursor cursor = dbHelper.getUserDetailsAppointment(username);
        if (cursor.moveToFirst()) {
            // Retrieving username, phone number & address
            String name = cursor.getString(0);
            String phonenum = cursor.getString(2);
            String address = cursor.getString(1);

            // Populating the EditText fields
            cInputName.setText(name);
            cInputPhoneNo.setText(phonenum);
            cInputAddress.setText(address);

        } else {
            Toast.makeText(ClientAppointment.this, "User data not found", Toast.LENGTH_SHORT).show();
        }


        // For service provider autocomplete field
        // Retrieving service provider names to autocomplete service provider EditText field
        ArrayList<String> spNames = dbHelper.getServiceProviders();
        ArrayAdapter<String> autocompleteSP = new ArrayAdapter<>(ClientAppointment.this, android.R.layout.simple_list_item_1, spNames);
        serviceProviderName.setAdapter(autocompleteSP);

        // For 'confirm appointment' button
        // Confirm appointment button
        Button confirmBtn = findViewById(R.id.confirmApt);
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieving the user input values
                String cName = cInputName.getText().toString().trim();
                String cPhone = cInputPhoneNo.getText().toString().trim();
                String cAddress = cInputAddress.getText().toString().trim();
                String cSP = serviceProviderName.getText().toString().trim();
                String cReason = cInputReason.getText().toString().trim();
                // Date: use 'formattedDate' variable
                // Time: combine 'formattedTime' (time) & 'cInputTimeOfDay' (AM/PM) variables
                // Service type: use 'cInputServiceType' variable


                // Handling the insertion of appointment details into the database
                boolean allFieldsFilled = false;

                // Allowing user to retry inserting their details if any fields are empty
                while (allFieldsFilled == false) {
                    // If any fields left empty, prompt user to fill out all fields
                    if (cName.isEmpty() || cPhone.isEmpty() || cAddress.isEmpty() || cSP.isEmpty() || cReason.isEmpty() ||
                            formattedDate.isEmpty() || formattedTime.isEmpty() || cInputTimeOfDay.isEmpty() || cInputServiceType.isEmpty()) {

                        // Show alert dialog to prompt user to field in all fields
                        emptyFieldAlert();
                        return;
                    } else {
                        // If all fields are filled out, call the method to handle the appointment creation
                        createAppointment(cName, cPhone, cAddress, cSP, cReason);
                        allFieldsFilled = true;
                    }
                }


                // Redirecting user back to home page
                Intent intent = new Intent(ClientAppointment.this, MainActivity.class);
                intent.putExtra("username", username); // username retrieved from the Intent
                intent.putExtra("userType", userType); // userType retrieved from the Intent
                startActivity(intent);
            }
        });
    }


    private void createAppointment(String clientName, String clientPhone, String clientAddress, String selectServiceProvider, String clientReason) {

        // Combining formatted time & time of day
        // Saving the time as (e.g. 8:30 AM)
        String appointmentTime = formattedTime + " " + cInputTimeOfDay;


        // Inserting appointment details into the database
        long result = dbHelper.insertPendingAppointment(clientName, clientPhone, clientAddress, formattedDate, appointmentTime, selectServiceProvider, clientReason, cInputServiceType);

        if (result != -1) {
            // Insertion was successful
            Toast.makeText(ClientAppointment.this, "Appointment successfully made", Toast.LENGTH_SHORT).show();
        } else {
            // Insertion failed
            Log.e("Couldn't make new appointment", "Error creating new appointment: " + result);
            Toast.makeText(ClientAppointment.this, "Couldn't make new appointment", Toast.LENGTH_SHORT).show();
        }


        // Clearing all fields in the UI
        clearUIFields();
    }


    private void clearUIFields() {
        // Clear all fields
        cInputName.setText("");
        cInputPhoneNo.setText("");
        cInputAddress.setText("");
        cShowInputDate.setText("");
        cInputTime.setText("");
        timeOfDaySpinner.setSelection(0);
        serviceProviderName.setText("");
        cInputReason.setText("");
        serviceTypeSpinner.setSelection(0);
    }


    private void emptyFieldAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ClientAppointment.this);
        builder.setMessage("Please fill out all fields");
        builder.setPositiveButton("OK", null);

        AlertDialog alertPopUp = builder.create();
        alertPopUp.show();
    }

}