package com.example.swiftfix;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import com.example.swiftfix.databinding.ActivityMainBinding;


public class Database extends SQLiteOpenHelper {

    public Database(Context context) {
        super(context, "User.db", null, 1 );
    }

    @Override
    public void onCreate(SQLiteDatabase DB){

        DB.execSQL("create Table Userdata(editName TEXT primary key, editPhone TEXT, editEmail TEXT, editPw TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("Drop table if exists Userdata");
    }
        public Boolean edituserdata(String editName, String editPhone, String editEmail, String editPw){

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("phone", editPhone);
        contentValues.put("email", editEmail);
            contentValues.put("pw", editPw);
            Cursor cursor = DB.rawQuery("Select * from Userdata where editName = ?", new String[] {editName});

            if(cursor.getCount()>0){
                long result=DB.update("Userdata", contentValues, "name=?", new String[] {editName});
                if (result==-1){
                    return false;
                }else{
                    return true;
                }
            }else
            {
            return false;
        }

}
}
