package com.example.swiftfix;


import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HistoryList extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> serviceName;
    Database2 DB;
    HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_history);
        DB =  new Database2(this);
        serviceName = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewHistory);
        adapter = new HistoryAdapter(this,serviceName);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displaydata();

    }

    private void displaydata() {

        Cursor cursor = DB.getdata();
        if(cursor.getCount()==0){
            Toast.makeText(HistoryList.this, "No Data Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext())
            {
                serviceName.add(cursor.getString(0));
            }
        }
    }

}
