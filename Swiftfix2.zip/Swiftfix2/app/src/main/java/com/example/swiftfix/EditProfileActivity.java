package com.example.swiftfix;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    private EditText editName, editPhone, editEmail, editPassword, editAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        // Initialize UI elements
        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        editAddress = findViewById(R.id.editAddress);

        ImageButton notibackButton = findViewById(R.id.notiBackBtn2);

        notibackButton.setOnClickListener(view -> {
            onBackPressed();
        });

        // Retrieve the username passed from the previous activity
        String username = getIntent().getStringExtra("username");

        // Use the username to fetch the user's existing profile data
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Cursor cursor = dbHelper.getUserData(username);

        if (cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex("name");
            int phoneIndex = cursor.getColumnIndex("phonenum");
            int emailIndex = cursor.getColumnIndex("email");
            int passwordIndex = cursor.getColumnIndex("password");
            int addressIndex = cursor.getColumnIndex("address");

            if (nameIndex != -1) {
                String name = cursor.getString(nameIndex);
                editName.setText(name);
            }

            if (phoneIndex != -1) {
                String phone = cursor.getString(phoneIndex);
                editPhone.setText(phone);
            }

            if (emailIndex != -1) {
                String email = cursor.getString(emailIndex);
                editEmail.setText(email);
            }

            if (passwordIndex != -1) {
                String password = cursor.getString(passwordIndex);
                editPassword.setText(password);
            }

            if (addressIndex != -1) {
                String password = cursor.getString(addressIndex);
                editAddress.setText(password);
            }
        }


        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the edited profile data
                String newName = editName.getText().toString();
                String newPhone = editPhone.getText().toString();
                String newEmail = editEmail.getText().toString();
                String newPassword = editPassword.getText().toString();
                String newAddress = editAddress.getText().toString();

                // Update the user's profile data in the database
                boolean updateResult = dbHelper.updateUserProfile(username, newName, newPhone, newEmail, newPassword, newAddress);

                if (updateResult) {
                    // Show a message to confirm the data has been updated
                    Toast.makeText(EditProfileActivity.this, "Profile updated successfully", Toast.LENGTH_SHORT).show();

                    // Finish the activity and return to the user profile

                } else {
                    // Handle the case where the update fails
                    Toast.makeText(EditProfileActivity.this, "Failed to update profile", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
