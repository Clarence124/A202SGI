package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class ProfileActivity extends AppCompatActivity {

    private Button Edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_profile);

        Edit = (Button) findViewById(R.id.Edit);
        Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUserEdit();
            }
        });
    }

    public void openUserEdit(){
        Intent intent = new Intent(ProfileActivity.this, ProfileEditActivity.class);
        startActivity(intent);
    }

}
