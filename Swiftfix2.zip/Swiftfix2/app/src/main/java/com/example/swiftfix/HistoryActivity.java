package com.example.swiftfix;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.swiftfix.R;


public class HistoryActivity extends AppCompatActivity {

    private Button backBtn;
    private Button Upcoming;
    private Button History;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_history);

        // Retrieving username & userType from Intent
        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");


        // Configuring back button
        backBtn = findViewById(R.id.back_button);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HistoryActivity.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("userType", userType);
                startActivity(intent);
            }
        });



        Upcoming = (Button) findViewById(R.id.Upcoming);
        Upcoming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUpcoming();
            }
        });

        History = (Button) findViewById(R.id.History);
        History.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHistory();
            }
        });

    }

    public void openUpcoming(){
        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");

        Intent spAppointmentIntent = new Intent(HistoryActivity.this, UpcomingList.class);
        spAppointmentIntent.putExtra("username", username);
        spAppointmentIntent.putExtra("userType", userType);
        startActivity(spAppointmentIntent);

    }

    public void openHistory(){
        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");

        Intent spAppointmentIntent = new Intent(HistoryActivity.this, HistoryList.class);
        spAppointmentIntent.putExtra("username", username);
        spAppointmentIntent.putExtra("userType", userType);
        startActivity(spAppointmentIntent);
    }

}