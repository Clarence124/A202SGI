package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import com.example.swiftfix.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        binding = ActivityMainBinding.inflate(getLayoutInflater());


        setSupportActionBar(binding.appBarMain.toolbar);

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_user_profile, R.id.nav_appointment, R.id.nav_notification,R.id.nav_history, R.id.nav_upcoming,R.id.nav_log_out)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(MainActivity.this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(MainActivity.this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        Button seeAllButton = findViewById(R.id.seeAllButton);
        seeAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SeeAllActivity.class);

                // Start the new activity
                startActivity(intent);
            }
        });

        ImageButton appointmentButton = findViewById(R.id.imageButton);
        ImageButton notificationButton = findViewById(R.id.imageButton1);
        ImageButton serviceHistoryButton = findViewById(R.id.imageButton2);
        ImageButton serviceImageButton1 = findViewById(R.id.imageButton7);
        ImageButton serviceImageButton2 = findViewById(R.id.imageButton8);
        ImageButton serviceImageButton3 = findViewById(R.id.imageButton9);
        ImageButton rectangle1ImageButton = findViewById(R.id.hseCleanbtn);
        ImageButton rectangle2ImageButton = findViewById(R.id.lightningBtn);
        ImageButton rectangle3ImageButton = findViewById(R.id.plumbingBtn);
        ImageButton rectangle4ImageButton = findViewById(R.id.aircondBtn);

        appointmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navController.navigate(R.id.nav_appointment);
            }
        });

        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to the "notification_fragment" when "Notification" button is clicked.
                navController.navigate(R.id.nav_notification);
            }
        });

        serviceHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to the "service_history_fragment" when "Service History" button is clicked.
                navController.navigate(R.id.nav_history);
            }
        });



        rectangle1ImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToServiceProfile("House cleaning");
            }
        });

        rectangle2ImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToServiceProfile("Lighting Service");
            }
        });

        rectangle3ImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToServiceProfile("Plumbing Check");
            }
        });

        rectangle4ImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToServiceProfile("Aircon Check");
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.onNavDestinationSelected(item, navController)
                || super.onOptionsItemSelected(item);
    }

    private void navigateToServiceProfile(String serviceType) {
        Intent intent = new Intent(getApplicationContext(), ServiceProfileActivity.class);
        intent.putExtra("service_type", serviceType);
        startActivity(intent);
    }
    public void onSeeAllButtonClick(View view) {
        Intent intent = new Intent(this, SeeAllActivity.class);
        startActivity(intent);
    }


}
