package com.example.swiftfix;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class ServiceProfileActivity extends AppCompatActivity {

    private SQLiteDatabase database;

    private TextView nameTextView,phoneNumberTextView,emailTextView,reviewsTextView, dateTV, timeTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_profile);

        // Assuming you have a DatabaseHelper class to manage your database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        database = dbHelper.getReadableDatabase();

        // Get the name of the selected service provider from the intent
        Intent intent = getIntent();
        String serviceProviderName = intent.getStringExtra("SERVICE_PROVIDER");

        Log.d("ServiceProfileActivity", "Selected Service Provider: " + serviceProviderName);

        Cursor cursor = dbHelper.getServiceProviderDataByName(serviceProviderName);

        // Display details in TextViews or other UI components
        nameTextView = findViewById(R.id.serviceProviderNameValue);
        phoneNumberTextView = findViewById(R.id.serviceProviderEditPhoneNo);
        emailTextView = findViewById(R.id.serviceProviderEditEmail);
        dateTV = findViewById(R.id.serviceDateTV);
        timeTV = findViewById(R.id.serviceTimeTV);
        reviewsTextView = findViewById(R.id.reviewEditText);

        Button back = findViewById(R.id.backBtn);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServiceProfileActivity.this, SeeAllActivity.class);
                startActivity(intent);
            }
        });

        Button saveButton = findViewById(R.id.savebutton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Assuming companyName is the data you want to pass to SeeAllActivity
                String companyName = nameTextView.getText().toString();

                // Create an Intent to go back to SeeAllActivity
                Intent intent = new Intent(ServiceProfileActivity.this, SeeAllActivity.class);

                // Pass the companyName as an extra to the intent
                intent.putExtra("COMPANY_NAME", companyName);

                // Start the SeeAllActivity with the new intent
                startActivity(intent);
            }
        });


        if (cursor.moveToFirst()) {
            // Retrieve details from the cursor
            int phoneNumberColumnIndex = cursor.getColumnIndex("phone_number");
            String phoneNumber = (phoneNumberColumnIndex >= 0) ? cursor.getString(phoneNumberColumnIndex) : "";

            int emailColumnIndex = cursor.getColumnIndex("email");
            String email = (emailColumnIndex >= 0) ? cursor.getString(emailColumnIndex) : "";

            int dateAvailableColumnIndex = cursor.getColumnIndex("date_available");
            String dateAvailable = (dateAvailableColumnIndex >= 0) ? cursor.getString(dateAvailableColumnIndex) : "";

            int timeAvailableColumnIndex = cursor.getColumnIndex("time_available");
            String timeAvailable = (timeAvailableColumnIndex >= 0) ? cursor.getString(timeAvailableColumnIndex) : "";

            int reviewsColumnIndex = cursor.getColumnIndex("reviews");
            String reviews = (reviewsColumnIndex >= 0) ? cursor.getString(reviewsColumnIndex) : "";


            nameTextView.setText(serviceProviderName);
            phoneNumberTextView.setText(phoneNumber);
            emailTextView.setText(email);
            dateTV.setText(dateAvailable);
            timeTV.setText(timeAvailable);
            reviewsTextView.setText(reviews);
        }

        // Close the cursor and database to avoid memory leaks
        cursor.close();
        database.close();
    }
}
