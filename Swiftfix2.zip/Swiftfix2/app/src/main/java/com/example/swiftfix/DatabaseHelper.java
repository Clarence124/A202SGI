package com.example.swiftfix;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "swiftfix.sqlite";

    // Create new appointment table
    private static final String APPOINTMENT_TABLE_NAME = "appointments";
    private static final String COL1_APPOINTMENT = "client_name";
    private static final String COL2_APPOINTMENT = "phonenum";
    private static final String COL3_APPOINTMENT = "address";
    private static final String COL4_APPOINTMENT = "appointment_date";
    private static final String COL5_APPOINTMENT = "appointment_time";
    private static final String COL6_APPOINTMENT = "selected_service_provider";
    private static final String COL7_APPOINTMENT = "reasonforappointment";
    private static final String COL8_APPOINTMENT = "servicetype";


    // Creating a dummy service provider table
    private static final String SERVICE_PROVIDER_TABLE_NAME = "dummy_service_provider";
    private static final String COL1_SP = "sp_name";
    private static final String COL2_SP = "sp_phonenum";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);

        // Debugging
        Log.d("DatabaseHelper", "Database version in constructor: " + getWritableDatabase().getVersion());
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Debugging
        Log.d("DatebaseHelper", "onCreate called. Initial Database version: " + db.getVersion());

        // Create the appointments table
        String createAppointmentTable = "CREATE TABLE " + APPOINTMENT_TABLE_NAME +
                " (appointment_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL1_APPOINTMENT + " TEXT, " +
                COL2_APPOINTMENT + " TEXT, " +
                COL3_APPOINTMENT + " TEXT, " +
                COL4_APPOINTMENT + " TEXT, " +
                COL5_APPOINTMENT + " TEXT, " +
                COL6_APPOINTMENT + " TEXT, " +
                COL7_APPOINTMENT + " TEXT, " +
                COL8_APPOINTMENT + " TEXT)";
        db.execSQL(createAppointmentTable);

        // Create the dummy service provider table
        String createServiceProviderTable = "CREATE TABLE " + SERVICE_PROVIDER_TABLE_NAME +
                " (sp_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL1_SP + " TEXT, " +
                COL2_SP + " TEXT)";
        db.execSQL(createServiceProviderTable);

        // Debugging
        Log.d("DatabaseHelper", "Tables created successfully");

//        insertDummySP();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Debugging
        Log.d("DatabaseHelper", "onUpgrade called. Old version: " + oldVersion + ", New version: " + newVersion);

        db.execSQL("DROP TABLE IF EXISTS " + APPOINTMENT_TABLE_NAME);
        onCreate(db);

        db.execSQL("DROP TABLE IF EXISTS " + SERVICE_PROVIDER_TABLE_NAME);
        onCreate(db);
    }

    // Appointments
    public long insertAppointment(String clientName, String clientPhone, String clientAddress, String appointmentDate, String appointmentTime, String selectServiceProvider, String appointmentReason, String serviceType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1_APPOINTMENT, clientName);
        contentValues.put(COL2_APPOINTMENT, clientPhone);
        contentValues.put(COL3_APPOINTMENT, clientAddress);
        contentValues.put(COL4_APPOINTMENT, appointmentDate);
        contentValues.put(COL5_APPOINTMENT, appointmentTime);
        contentValues.put(COL6_APPOINTMENT, selectServiceProvider);
        contentValues.put(COL7_APPOINTMENT, appointmentReason);
        contentValues.put(COL8_APPOINTMENT, serviceType);
        return db.insert(APPOINTMENT_TABLE_NAME, null, contentValues);
    }

    // Retrieving appointment data
    public Cursor getAppointment(){
        // Debugging
        Log.d("DatabaseHelper", "Retrieving appointment data from database");

        SQLiteDatabase DB = this.getWritableDatabase();
//        Cursor cursor = DB.rawQuery("Select * from " + APPOINTMENT_TABLE_NAME, null);
        String[] columns = {COL4_APPOINTMENT, COL5_APPOINTMENT, COL6_APPOINTMENT}; // Querying the service provider name, date & time of appointment
//        String selection = COL1_APPOINTMENT + " = ?";
//        String[] selectionArgs = {username};      // these need to display based on username
        return DB.query(APPOINTMENT_TABLE_NAME, columns, null, null, null , null, null);
    }

    public Cursor getOldAppointment() {
        //Debugging
        Log.d("DatabaseHelper", "Retrieving old appointments from database");

        SQLiteDatabase DB = this.getWritableDatabase();
//        Cursor cursor = DB.rawQuery("Select * from " + APPOINTMENT_TABLE_NAME, null);
        String[] columns = {COL6_APPOINTMENT, COL7_APPOINTMENT}; // Querying the service provider name, date & time of appointment
//        String selection = COL1_APPOINTMENT + " = ?";
//        String[] selectionArgs = {username};      // these need to display based on username
        return DB.query(APPOINTMENT_TABLE_NAME, columns, null, null, null , null, null);
    }

    // For client appointment page - autocomplete field for service provider names
    public ArrayList<String> getServiceProviders() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> allSP = new ArrayList<>();
        String[] column = {COL1_APPOINTMENT};
        Cursor cursor = db.query(APPOINTMENT_TABLE_NAME, column, null,null, null, null, null);

        // Adding the service providers' names into the ArrayList object
        if (cursor != null) {
            int columnIndex = cursor.getColumnIndex(COL1_APPOINTMENT);
            if (columnIndex != -1 && cursor.moveToFirst()) {
                do {
                    allSP.add(cursor.getString(columnIndex));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        return allSP;
    }


}
