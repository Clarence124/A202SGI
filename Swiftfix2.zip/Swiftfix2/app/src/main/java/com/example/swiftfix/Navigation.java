package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.navigation.NavigationView.OnNavigationItemSelectedListener;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Navigation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NavigationView navigationView = findViewById(R.id.nav_view);

        navigationView.setNavigationItemSelectedListener(new OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.nav_user_profile) {
                    // Open the userProfile activity
                    Intent userProfileIntent = new Intent(Navigation.this, userProfile.class);
                    startActivity(userProfileIntent);
                }

                if (id == R.id.nav_notification) {
                    // Open the NotificationPage activity
                    Intent notificationPageIntent = new Intent(Navigation.this, NotificationPage.class);
                    startActivity(notificationPageIntent);
                }

                return true;
            }
        });
    }
}

