package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SeeAllActivity extends AppCompatActivity {
    private LinearLayout rectangle1Container;
    private LinearLayout rectangle2Container;
    private LinearLayout rectangle3Container;
    private LinearLayout rectangle4Container;

    private List<ServiceItem> allServiceItems;
    private List<ServiceItem> displayedServiceItems;

    private SearchView searchView;
    private Spinner spinner;
    private ImageButton houseCleaningButton;
    private ImageButton lightingCareButton;
    private ImageButton aircondCheckButton;
    private ImageButton plumbingCheckButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.see_all);

        // Initialize UI elements
        searchView = findViewById(R.id.search_View);
        Button backButton = findViewById(R.id.backBtn);
        spinner = findViewById(R.id.spinner);

        rectangle1Container = findViewById(R.id.rectangle1Container);
        rectangle2Container = findViewById(R.id.rectangle2Container);
        rectangle3Container = findViewById(R.id.rectangle3Container);
        rectangle4Container = findViewById(R.id.rectangle4Container);

        initializeData();

        setupSearchView();

        setupBackButton(backButton);

        setupSpinner();

        // Initialize Buttons
        houseCleaningButton = findViewById(R.id.hseCleanbtn);
        lightingCareButton = findViewById(R.id.lightningBtn);
        aircondCheckButton = findViewById(R.id.aircondBtn);
        plumbingCheckButton = findViewById(R.id.plumbingBtn);
        

        // Set click listeners for buttons
        houseCleaningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("HouseFixers");
            }
        });

        lightingCareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("LightningCare Solution");
            }
        });

        aircondCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("FreshAir");
            }
        });

        plumbingCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("Plumbing Solution");
            }
        });
    }

    private void openServiceProviderPage(String serviceProvider) {
        // Display a toast message with the selected service provider
        Toast.makeText(this, "Clicked on " + serviceProvider, Toast.LENGTH_SHORT).show();

        // Pass the service provider name to ServiceProfileActivity
        Intent intent = new Intent(this, ServiceProfileActivity.class);
        intent.putExtra("SERVICE_PROVIDER", serviceProvider);
        startActivity(intent);
    }

    private void initializeData() {
        allServiceItems = new ArrayList<>();
        allServiceItems.add(new ServiceItem("House cleaning", "Company A"));
        allServiceItems.add(new ServiceItem("Lighting Service", "Company B"));
        allServiceItems.add(new ServiceItem("Plumbing Check", "Company C"));
        allServiceItems.add(new ServiceItem("Aircon Check", "Company D"));

        displayedServiceItems = new ArrayList<>(allServiceItems);
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterAndDisplay();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterAndDisplay();
                return true;
            }
        });
    }

    private void setupBackButton(Button backButton) {
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void setupSpinner() {
        // Define your spinner items in strings.xml
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.spinner_items,
                android.R.layout.simple_spinner_item
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                filterAndDisplay();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Handle the case where nothing is selected (if needed)
            }
        });
    }

    private void filterAndDisplay() {
        String query = searchView.getQuery().toString().toLowerCase();
        int selectedPosition = spinner.getSelectedItemPosition();
        int selectedTypePosition = spinner.getSelectedItemPosition();

        displayedServiceItems.clear();

        for (ServiceItem item : allServiceItems) {
            if (selectedPosition == 0 || selectedPosition == 1 && item.isService() || selectedPosition == 2 && !item.isService()) {
                if (query.isEmpty() || item.getCompanyName().toLowerCase().contains(query)) {
                    displayedServiceItems.add(item);
                }
            }
        }

        updateUI();
    }

    private void updateUI() {
        for (ServiceItem item : displayedServiceItems) {
            LinearLayout container = getContainerForItem(item);
            container.setVisibility(View.VISIBLE);

            TextView textView = container.findViewById(getTextViewId(container.getId()));
            textView.setText(item.getServiceName());

            ImageButton imageButton = container.findViewById(getImageButtonId(container.getId()));
            // Set up image button as needed

            Spinner serviceSpinner = findViewById(R.id.spinner);
            Spinner companySpinner = container.findViewById(getCompanyNameSpinnerId(container.getId()));

            // Populate the service spinner based on whether it's a service or maintenance
            List<String> serviceOptions;
            if (item.isService()) {
                serviceOptions = Arrays.asList(getResources().getStringArray(R.array.service_items));
            } else {
                serviceOptions = Arrays.asList(getResources().getStringArray(R.array.maintenance_items));
            }

            ArrayAdapter<String> serviceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, serviceOptions);
            serviceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            serviceSpinner.setAdapter(serviceAdapter);

            // Populate the company name spinner based on your logic
            List<String> companyNames;
            // You need to define a method to get company names based on the selected service
            // For now, let's assume you have a method getCompanyNamesForService in your ServiceItem class
            companyNames = item.getCompanyNames();

            ArrayAdapter<String> companyAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, companyNames);
            companyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            companySpinner.setAdapter(companyAdapter);
        }
    }

    private int getTextViewId(int containerId) {
        return getResources().getIdentifier("rectangle" + containerId + "_textView", "id", getPackageName());
    }

    private int getImageButtonId(int containerId) {
        return getResources().getIdentifier("rectangle" + containerId + "_imageButton", "id", getPackageName());
    }

    private void updateCompanyNameSpinner(String title, String companyName) {
        // Get the LinearLayout container based on the title
        LinearLayout container = getContainerForTitle(title);
        if (container != null) {
            // Find the companyNameSpinner inside the container
            Spinner companyNameSpinner = container.findViewById(getCompanyNameSpinnerId(container.getId()));

            // Update the companyNameSpinner with the new companyName
            ArrayAdapter<String> companyAdapter = (ArrayAdapter<String>) companyNameSpinner.getAdapter();
            companyAdapter.add(companyName);
            companyAdapter.notifyDataSetChanged();
        }
    }

    private int getCompanyNameSpinnerId(int containerId) {
        if (containerId == R.id.rectangle1Container) {
            return R.id.companyNameSpinner1;
        } else if (containerId == R.id.rectangle2Container) {
            return R.id.companyNameSpinner2;
        } else if (containerId == R.id.rectangle3Container) {
            return R.id.companyNameSpinner3;
        } else if (containerId == R.id.rectangle4Container) {
            return R.id.companyNameSpinner4;
        } else {
            return 0; // Return an appropriate default value
        }
    }


    private LinearLayout getContainerForTitle(String title) {
        switch (title) {
            case "House cleaning":
                return findViewById(R.id.rectangle1Container);
            case "Lighting Service":
                return findViewById(R.id.rectangle2Container);
            case "Plumbing Check":
                return findViewById(R.id.rectangle3Container);
            case "Aircond Check":
                return findViewById(R.id.rectangle4Container);
            // Add cases for other titles as needed
            default:
                return null;
        }
    }




    private LinearLayout getContainerForItem(ServiceItem item) {
        switch (item.getServiceName()) {
            case "House cleaning":
                return rectangle1Container;
            case "Lighting Service":
                return rectangle2Container;
            case "Plumbing Check":
                return rectangle3Container;
            case "Aircon Check":
                return rectangle4Container;
            default:
                return rectangle1Container;
        }
    }

    private void hideAllContainers() {
        rectangle1Container.setVisibility(View.GONE);
        rectangle2Container.setVisibility(View.GONE);
        rectangle3Container.setVisibility(View.GONE);
        rectangle4Container.setVisibility(View.GONE);
    }

    public class ServiceItem {
        private String serviceName;
        private String companyName;

        public ServiceItem(String serviceName, String companyName) {
            this.serviceName = serviceName;
            this.companyName = companyName;
        }

        public String getServiceName() {
            return serviceName;
        }

        public String getCompanyName() {
            return companyName;
        }

        public boolean isService() {
            // You might have a more sophisticated way to determine if it's a service or maintenance
            return serviceName.equals("House cleaning") || serviceName.equals("Lighting Service");
        }

        public List<String> getCompanyNames() {
            List<String> companyNames = new ArrayList<>();

            if (isService()) {
                // For service, add specific company names
                if (serviceName.equals("House cleaning")) {
                    companyNames.add("Cleaning Company 1");
                    companyNames.add("Cleaning Company 2");
                } else if (serviceName.equals("Lighting Service")) {
                    companyNames.add("Lighting Company 1");
                    companyNames.add("Lighting Company 2");
                }
                // Add more companies as needed for other services
            } else {
                // For maintenance, add different company names
                if (serviceName.equals("Plumbing Check")) {
                    companyNames.add("Plumbing Company 1");
                    companyNames.add("Plumbing Company 2");
                } else if (serviceName.equals("Aircon Check")) {
                    companyNames.add("Aircon Company 1");
                    companyNames.add("Aircon Company 2");
                }
                // Add more companies as needed for other maintenance services
            }

            return companyNames;
        }

    }
}
