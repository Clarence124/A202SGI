package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SeeAllActivity extends AppCompatActivity {

    private ImageButton houseCleaningButton;
    private ImageButton lightingCareButton;
    private ImageButton aircondCheckButton;
    private ImageButton plumbingCheckButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.see_all);

        // Initialize Buttons
        houseCleaningButton = findViewById(R.id.hseCleanbtn);
        lightingCareButton = findViewById(R.id.lightningBtn);
        aircondCheckButton = findViewById(R.id.aircondBtn);
        plumbingCheckButton = findViewById(R.id.plumbingBtn);
        

        // Set click listeners for buttons
        houseCleaningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("HouseFixers");
            }
        });

        lightingCareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("LightningCare Solution");
            }
        });

        aircondCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("FreshAir");
            }
        });

        plumbingCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServiceProviderPage("Plumbing Solution");
            }
        });
    }

    private void openServiceProviderPage(String serviceProvider) {
        // Display a toast message with the selected service provider
        Toast.makeText(this, "Clicked on " + serviceProvider, Toast.LENGTH_SHORT).show();

        // Pass the service provider name to ServiceProfileActivity
        Intent intent = new Intent(this, ServiceProfileActivity.class);
        intent.putExtra("SERVICE_PROVIDER", serviceProvider);
        startActivity(intent);
    }
}
