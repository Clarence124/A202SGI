package com.example.swiftfix;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UpcomingList extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> serviceName, Dnt;
    DatabaseHelper dbHelper;
    UpcomingAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_upcoming);
        dbHelper =  new DatabaseHelper(this);
        serviceName = new ArrayList<>();
        Dnt = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewUpcoming);
        adapter = new UpcomingAdapter(this,serviceName, Dnt);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        displaydata();

    }

    private void displaydata() {

        Cursor cursor = dbHelper.getAppointment();
        if(cursor.getCount()==0){
            Toast.makeText(UpcomingList.this, "No Data Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext())
            {
                serviceName.add(cursor.getString(2));
                Dnt.add(cursor.getString(0) + ", " + cursor.getString(1));
            }

            // Debugging
            for (int i = 0; i < serviceName.size(); i++) {
                Log.d("Database Data", "Service Name: " + serviceName.get(i) + ", Date & Time: " + Dnt.get(i));
            }
        }
    }

}