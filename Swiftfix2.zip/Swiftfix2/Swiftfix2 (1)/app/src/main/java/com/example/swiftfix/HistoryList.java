package com.example.swiftfix;



import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.sql.Array;
import java.util.ArrayList;

public class HistoryList extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> serviceName;
    DatabaseHelper dbHelper;
    HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_history);
        dbHelper =  new DatabaseHelper(this);
        serviceName = new ArrayList<>();
//        serviceReason = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewHistory);
        adapter = new HistoryAdapter(this,serviceName);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        displaydata();

    }

    private void displaydata() {

        Cursor cursor = dbHelper.getOldAppointment();
        if(cursor.getCount()==0){
            Toast.makeText(HistoryList.this, "No Data Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext())
            {
                serviceName.add(cursor.getString(0));
//                serviceReason.add(cursor.getString(1));

                // Debugging
                for (int i = 0; i < serviceName.size(); i++) {
                    Log.d("Database Data", "Service Name: " + serviceName.get(i));
                }
            }
        }
    }

}
