package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.navigation.NavigationView.OnNavigationItemSelectedListener;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import androidx.drawerlayout.widget.DrawerLayout;
import com.example.swiftfix.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");


        Log.d("UserProfile", "Username: " + username);


        navigationView.setNavigationItemSelectedListener(new OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.nav_user_profile) {
                    // Open the userProfile activity
                    Intent userProfileIntent = new Intent(MainActivity.this, userProfile.class);
                    userProfileIntent.putExtra("username", username);
                    startActivity(userProfileIntent);
                }

                if (id == R.id.nav_appointment) {
                    // Open the NotificationPage activity
                    Intent appointmentPageIntent = new Intent(MainActivity.this, ClientAppointment.class);
                    startActivity(appointmentPageIntent);
                }

                if (id == R.id.nav_notification) {
                    // Open the NotificationPage activity
                    Intent notificationPageIntent = new Intent(MainActivity.this, NotificationPage.class);
                    startActivity(notificationPageIntent);
                }

                if (id == R.id.nav_history) {
                    // Open the NotificationPage activity
                    Intent historyPageIntent = new Intent(MainActivity.this, HistoryActivity.class);
                    startActivity(historyPageIntent);
                }

                if (id == R.id.nav_upcoming) {
                    // Open the NotificationPage activity
                    Intent upcomingPageIntent = new Intent(MainActivity.this, UpcomingActivity.class);
                    startActivity(upcomingPageIntent);
                }

                if (id == R.id.nav_log_out) {
                    // Open the NotificationPage activity
                    Intent logoutPageIntent = new Intent(MainActivity.this, LoginPage.class);
                    startActivity(logoutPageIntent);
                }

                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });


        Button seeAllButton = findViewById(R.id.seeAllButton);
        seeAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SeeAllActivity.class);
                startActivity(intent);
            }
        });


        ImageButton appointmentButton = findViewById(R.id.imageButton);
        ImageButton notificationButton = findViewById(R.id.imageButton1);
        ImageButton serviceHistoryButton = findViewById(R.id.imageButton2);
        ImageButton serviceImageButton1 = findViewById(R.id.imageButton7);
        ImageButton serviceImageButton2 = findViewById(R.id.imageButton8);
        ImageButton serviceImageButton3 = findViewById(R.id.imageButton9);


        appointmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the click for "Appointment" button
                if ("User".equals(userType)) {
                    Intent clientAppointmentIntent = new Intent(MainActivity.this, ClientAppointment.class);
                    clientAppointmentIntent.putExtra("username", username);
                    clientAppointmentIntent.putExtra("userType", userType);
                    startActivity(clientAppointmentIntent);
                } else {
                    Intent spAppointmentIntent = new Intent(MainActivity.this, SPAppointment.class);
                    spAppointmentIntent.putExtra("username", username);
                    spAppointmentIntent.putExtra("userType", userType);
                    startActivity(spAppointmentIntent);
                }
            }
        });

        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the click for "Notification" button
                Intent notificationIntent = new Intent(MainActivity.this, NotificationPage.class);
                startActivity(notificationIntent);
            }
        });

        serviceHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the click for "Service History" button
                Intent serviceHistoryIntent = new Intent(MainActivity.this,HistoryActivity.class);
                startActivity(serviceHistoryIntent);
            }
        });



        serviceImageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToServiceProfile("House cleaning");
            }
        });

        serviceImageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToServiceProfile("Window cleaning");
            }
        });

        serviceImageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToServiceProfile("Elevator maintenance");
            }
        });

    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    private void navigateToServiceProfile(String serviceType) {
        Intent intent = new Intent(getApplicationContext(), ServiceProfileActivity.class);
        intent.putExtra("service_type", serviceType);
        startActivity(intent);
    }
    public void onSeeAllButtonClick(View view) {
        Intent intent = new Intent(this, SeeAllActivity.class);
        startActivity(intent);
    }




}
