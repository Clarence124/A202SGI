package com.example.swiftfix;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import android.content.Context;
public class Database2 extends SQLiteOpenHelper {



    public Database2(Context context) {
        super(context, "Data.db", null, 1 );
    }

    @Override
    public void onCreate(SQLiteDatabase DB){

        DB.execSQL("create Table Servicedata(Name TEXT primary key, Phone TEXT, Address TEXT, Time TEXT, " +
                "serviceName TEXT, Reason TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("Drop table if exists Entereddata");
    }


    public Boolean insertdata(String name, String phone, String address, String time , String serviceName, String reason) {

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Name", name);
        contentValues.put("Email", phone);
        contentValues.put("Address", address);
        contentValues.put("Time", time);
        contentValues.put("serviceName", serviceName);
        contentValues.put("Reason", reason);
        long result = DB.insert("Entereddata", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Cursor getdata(){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Servicedetails", null);
        return cursor;
    }
}


