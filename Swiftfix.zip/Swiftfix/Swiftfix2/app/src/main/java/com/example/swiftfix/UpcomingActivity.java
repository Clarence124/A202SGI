package com.example.swiftfix;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class UpcomingActivity extends AppCompatActivity {

    private Button backBtn;

    private Button Upcoming;
    private Button History;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_upcoming);

        // Retrieving username & userType from Intent
        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");


        // Configuring back button
        backBtn = findViewById(R.id.back_button);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UpcomingActivity.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("userType", userType);
                startActivity(intent);
            }
        });


        Upcoming = (Button) findViewById(R.id.Upcoming);
        Upcoming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUpcoming();
            }
        });

        History = (Button) findViewById(R.id.History);
        History.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHistory();
            }
        });

    }

    public void openUpcoming(){
        Intent intent = new Intent(UpcomingActivity.this, UpcomingList.class);
        startActivity(intent);
    }

    public void openHistory(){
        Intent intent = new Intent(UpcomingActivity.this, HistoryList.class);
        startActivity(intent);
    }

}