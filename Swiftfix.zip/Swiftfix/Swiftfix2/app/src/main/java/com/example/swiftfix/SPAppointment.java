package com.example.swiftfix;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SPAppointment extends AppCompatActivity {

    // Declaration of UI elements
    private Button backBtn, rejectAppBtn, acceptAppBtn;
    private TextView cName, cPhoneNo, cAddress, apDate, apTime, apReason, serviceType;

    // String variables holding appointment details from the database
    private String apID, name, phonenum, address, date, time, reason, service;

    // DatabaseHelper instance
    private DatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp_appointment);

        // Initialising UI elements
        backBtn = findViewById(R.id.backBtn);
        cName = findViewById(R.id.clientName);
        cPhoneNo = findViewById(R.id.clientPhoneNo);
        cAddress = findViewById(R.id.clientAddress);
        apDate = findViewById(R.id.dateDisplay);
        apTime = findViewById(R.id.appointmentTime);
        apReason = findViewById(R.id.appointmentReason);
        serviceType = findViewById(R.id.serviceType);
        rejectAppBtn = findViewById(R.id.rejectBtn);
        acceptAppBtn = findViewById(R.id.acceptBtn);

        // Retrieving username & userType from Intent
        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");


        // Configuring back button
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SPAppointment.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("userType", userType);
                startActivity(intent);
            }
        });


        // Initialising the database
        dbHelper = new DatabaseHelper(SPAppointment.this);

        // Retrieving relevant appointment data from the database
        Cursor cursor = dbHelper.getAppointmentSPView(username); // testing with hard coded username


        if (cursor.moveToFirst()) {
            // Retrieving data from the associated row
            apID = cursor.getString(0); // Appointment ID
            name = cursor.getString(1);
            phonenum = cursor.getString(2);
            address = cursor.getString(3);
            date = cursor.getString(4);
            time = cursor.getString(5);
            reason = cursor.getString(6);
            service = cursor.getString(7);


            // Populating the TextViews
            cName.setText(name);
            cPhoneNo.setText(phonenum);
            cAddress.setText(address);
            apDate.setText(date);
            apTime.setText(time);
            apReason.setText(reason);
            serviceType.setText(service);

        } else {
            Toast.makeText(SPAppointment.this, "No Data Exists", Toast.LENGTH_SHORT).show();
        }


        // Reject appointment button clicked
        rejectAppBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SPAppointment.this);
                builder.setMessage("Confirm Reject Appointment");
                builder.setNegativeButton("NO", null);
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Removing the appointment from pending appointments upon cancellation
                        removeAppointment(apID);

                        // Navigating to upcoming appointments
                        Intent intent = new Intent(SPAppointment.this, MainActivity.class);
                        intent.putExtra("username", username);
                        intent.putExtra("userType", userType);
                        startActivity(intent);
                    }
                });

                AlertDialog alertPopUp = builder.create();
                alertPopUp.show();
            }
        });


        // Accept appointment button clicked
        acceptAppBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SPAppointment.this);
                builder.setMessage("Confirm Accept Appointment");
                builder.setNegativeButton("NO", null);
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Inserting confirmed appointments into database
                        insertAppointmentConfirmed(apID, username); // Passing in the appointment ID & Service Provider's name into the database (via the database)

                        // Navigating to upcoming appointments
                        Intent intent = new Intent(SPAppointment.this, UpcomingActivity.class);
                        intent.putExtra("username", username);
                        intent.putExtra("userType", userType);
                        startActivity(intent);
                    }
                });

                AlertDialog alertPopUp = builder.create();
                alertPopUp.show();
            }
        });
    }


    private void insertAppointmentConfirmed(String appointmentID, String spUsername) {

        // Inserting confirmed appointments into the database
        long resultInsert = dbHelper.insertConfirmedAppointment(name, phonenum, address, date, time, spUsername, reason, service); // Username = Service Provider's name

        if (resultInsert != -1) {
            // Insertion was successful
            Toast.makeText(SPAppointment.this, "Appointment set", Toast.LENGTH_SHORT).show();
        } else {
            // Insertion failed
            Log.e("Couldn't confirm appointment", "Error confirming appointment: " + resultInsert);
            Toast.makeText(SPAppointment.this, "Couldn't set appointment", Toast.LENGTH_SHORT).show();
        }


        // Removing appointment from pending appointments table
        long resultRemove = dbHelper.removePendingAppointment(appointmentID);

        if (resultRemove != -1) {
            // Insertion was successful
            Log.d("SPAppointment", "Succesfully removed pending appointment" + appointmentID);
        } else {
            // Insertion failed
            Log.d("SPAppointment", "Error removing pending appointment");
        }
    }


    private void removeAppointment(String appointmentID) {
        long resultRemove = dbHelper.removePendingAppointment(appointmentID);

        if (resultRemove != -1) {
            // Deletion was successful
            Toast.makeText(SPAppointment.this, "Appointment cancelled", Toast.LENGTH_SHORT).show();
        } else {
            // Deletion failed
            Log.e("Couldn't cancel appointment", "Error cancelling appointment: " + resultRemove);
            Toast.makeText(SPAppointment.this, "Couldn't cancel appointment", Toast.LENGTH_SHORT).show();
        }
    }
}