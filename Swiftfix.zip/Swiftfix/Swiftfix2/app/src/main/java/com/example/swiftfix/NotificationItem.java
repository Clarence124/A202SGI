package com.example.swiftfix;
public class NotificationItem {
    private String date;
    private String details;

    public NotificationItem(String date, String details) {
        this.date = date;
        this.details = details;
    }

    public String getDate() {
        return date;
    }

    public String getDetails() {
        return details;
    }
}
