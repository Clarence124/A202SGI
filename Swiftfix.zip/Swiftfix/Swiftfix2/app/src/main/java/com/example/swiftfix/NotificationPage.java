package com.example.swiftfix;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NotificationPage extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_page);

        RecyclerView notificationRecyclerView = findViewById(R.id.notificationRecyclerView);
        notificationRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        ImageButton notibackButton = findViewById(R.id.notiBackBtn);

        notibackButton.setOnClickListener(view -> {
            onBackPressed();
        });

        // Create a list of notification items
        List<NotificationItem> notificationItems = getNotificationItems();

        // Create and set the custom adapter
        NotificationAdapter adapter = new NotificationAdapter(notificationItems);
        notificationRecyclerView.setAdapter(adapter);
    }

    // Replace this with your logic to fetch notification data from the database
    private List<NotificationItem> getNotificationItems() {
        List<NotificationItem> notificationItems = new ArrayList<>();
        notificationItems.add(new NotificationItem("2023-11-01", "Your appointment details."));
        notificationItems.add(new NotificationItem("2023-11-05", "Another appointment details."));
        notificationItems.add(new NotificationItem("2023-11-10", "Third appointment details."));
        return notificationItems;
    }
}
