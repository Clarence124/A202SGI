package com.example.swiftfix;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class userProfile extends AppCompatActivity {

    TextView nameTextView, phoneTextView, emailTextView, passwordTextView, addressTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        Log.d("UserProfile", "UserProfile activity started.");

        nameTextView = findViewById(R.id.nameView);
        phoneTextView = findViewById(R.id.numView);
        emailTextView = findViewById(R.id.emailView);
        passwordTextView = findViewById(R.id.passView);
        addressTextView = findViewById(R.id.addressView);


        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");


        Log.d("UserProfile", "Username: " + username);
        Log.d("UserProfile", "UserType: " + userType);

        Button editBtn = findViewById(R.id.btnEdit);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to open the EditProfileActivity
                Intent editProfileIntent = new Intent(userProfile.this, EditProfileActivity.class);

                // Pass the username and current user data as extras to the EditProfileActivity
                editProfileIntent.putExtra("username", username);
                editProfileIntent.putExtra("name", nameTextView.getText().toString());
                editProfileIntent.putExtra("phone", phoneTextView.getText().toString());
                editProfileIntent.putExtra("email", emailTextView.getText().toString());
                editProfileIntent.putExtra("password", passwordTextView.getText().toString());
                editProfileIntent.putExtra("address", addressTextView.getText().toString());

                startActivity(editProfileIntent);
            }
        });

        if (username != null) {
            // Create an instance of the DatabaseHelper
            DatabaseHelper dbHelper = new DatabaseHelper(this);

            // Use the userType to fetch user data
            Cursor cursor = dbHelper.getUserData(username);

            if (cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex("name");
                int phoneIndex = cursor.getColumnIndex("phonenum");
                int emailIndex = cursor.getColumnIndex("email");
                int passwordIndex = cursor.getColumnIndex("password");
                int addressIndex = cursor.getColumnIndex("address");

                if (nameIndex != -1) {
                    String name = cursor.getString(nameIndex);
                    nameTextView.setText(getString(R.string.name_label, name));
                } else {
                    nameTextView.setText(getString(R.string.name_label, getString(R.string.placeholder)));
                }

                if (phoneIndex != -1) {
                    String phone = cursor.getString(phoneIndex);
                    phoneTextView.setText(getString(R.string.phone_label, phone));
                } else {
                    phoneTextView.setText(getString(R.string.phone_label, getString(R.string.placeholder)));
                }

                if (emailIndex != -1) {
                    String email = cursor.getString(emailIndex);
                    emailTextView.setText(getString(R.string.email_label, email));
                } else {
                    emailTextView.setText(getString(R.string.email_label, getString(R.string.placeholder)));
                }

                if (passwordIndex != -1) {
                    String password = cursor.getString(passwordIndex);
                    passwordTextView.setText(getString(R.string.password_label, password));
                } else {
                    passwordTextView.setText(getString(R.string.password_label, getString(R.string.placeholder)));
                }

                if (addressIndex != -1) {
                    String address = cursor.getString(addressIndex);
                    addressTextView.setText(getString(R.string.address_label, address));
                } else {
                    addressTextView.setText(getString(R.string.address_label, getString(R.string.placeholder)));
                }
            } else {
                // Handle the case where no data is found for the user
                nameTextView.setText(getString(R.string.name_label, getString(R.string.placeholder)));
                phoneTextView.setText(getString(R.string.phone_label, getString(R.string.placeholder)));
                emailTextView.setText(getString(R.string.email_label, getString(R.string.placeholder)));
                passwordTextView.setText(getString(R.string.password_label, getString(R.string.placeholder)));
                addressTextView.setText(getString(R.string.address_label, getString(R.string.placeholder)));
            }

            cursor.close();
        }

    }


}
