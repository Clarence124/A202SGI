package com.example.swiftfixtest;


import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HistoryList extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> serviceName;
    DatabaseHelper dbHelper;
    HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_history);
        dbHelper =  new DatabaseHelper(this);
        serviceName = new ArrayList<>();
//        serviceReason = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewHistory);
        adapter = new HistoryAdapter(this,serviceName);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        displaydata();

    }

    private void displaydata() {
        String username = getIntent().getStringExtra("username");
        String userType = getIntent().getStringExtra("userType");



        if(userType=="User"){
            Cursor cursor = dbHelper.getOldAppointment(username);
            if(cursor.getCount()==0){
                Toast.makeText(HistoryList.this, "No Data Exists", Toast.LENGTH_SHORT).show();
                return;
            }
            else{
                while(cursor.moveToNext())
                {
                    serviceName.add(cursor.getString(2));

                }

                // Debugging
                for (int i = 0; i < serviceName.size(); i++) {
                    Log.d("Database Data", "Service Name: " + serviceName.get(i));
                }
            }

        }
        else{
            Cursor cursor = dbHelper.getOldAppointmentSP(username);
            if(cursor.getCount()==0){
                Toast.makeText(HistoryList.this, "No Data Exists", Toast.LENGTH_SHORT).show();
                return;
            }
            else{
                while(cursor.moveToNext())
                {
                    serviceName.add(cursor.getString(0));

                }

                // Debugging
                for (int i = 0; i < serviceName.size(); i++) {
                    Log.d("Database Data", "Service Name: " + serviceName.get(i));
                }
            }
        }

    }

}
