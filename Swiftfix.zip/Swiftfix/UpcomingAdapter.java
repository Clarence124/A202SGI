package com.example.swiftfixtest;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
public class UpcomingAdapter extends RecyclerView.Adapter<UpcomingAdapter.MyViewHolder> {

    private Context context;
    private ArrayList name_id, dnt_id;

    public UpcomingAdapter(Context context, ArrayList name_id, ArrayList dnt_id) {
        this.context = context;
        this.name_id = name_id;
        this.dnt_id = dnt_id;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.upcoming_entry,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UpcomingAdapter.MyViewHolder holder, int position) {

        holder.name_id.setText(String.valueOf(name_id.get(position)));
        holder.dnt_id.setText(String.valueOf(dnt_id.get(position)));
    }

    @Override
    public int getItemCount() {
        return name_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name_id, dnt_id;
        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            name_id = itemView.findViewById(R.id.serviceName);
            dnt_id = itemView.findViewById(R.id.Dnt);
        }

    }

}