package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

//EDITED
public class LoginPage extends AppCompatActivity {

    private EditText inputLoginUname, inputLoginPass;

    private RadioGroup loginUserType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        // Initialize UI elements
        inputLoginUname = findViewById(R.id.etUnameLogin);
        inputLoginPass = findViewById(R.id.etPassLogin);
        loginUserType = findViewById(R.id.rgLoginUserType);

        Button btnLoginUser = findViewById(R.id.btnLoginUser);

        // Set up a click listener for the Login button
        btnLoginUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call a method to handle the login process
                loginUser();
            }
        });
    }

    private void loginUser() {
        // Get user input from the EditText fields
        String username = inputLoginUname.getText().toString().trim();
        String password = inputLoginPass.getText().toString().trim();

        int selectedRadioButtonId = loginUserType.getCheckedRadioButtonId();
        RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);

        if (selectedRadioButton != null) {
            String userType = selectedRadioButton.getText().toString();

            DatabaseHelper dbHelper = new DatabaseHelper(this);
            boolean isValidUser = dbHelper.checkUserCredentials(username, password, userType);

            if (isValidUser) {
                // Credentials are valid, perform login actions
                String message = "Login successful as " + userType + ": " + username;
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(LoginPage.this, userHomepage.class);
                intent.putExtra("username", username); // Pass the username to the userHomepage
                intent.putExtra("userType", userType); // Pass the userType to the userHomepage
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else {
                // Invalid credentials, show an error message
                Toast.makeText(this, "Invalid username, password, or user type", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Handle the case where no radio button is selected
            Toast.makeText(this, "Please select a user type", Toast.LENGTH_SHORT).show();
        }
    }


}
