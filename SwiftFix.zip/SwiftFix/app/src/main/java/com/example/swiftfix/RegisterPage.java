package com.example.swiftfix;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class RegisterPage extends AppCompatActivity {

    private EditText inputName, inputPass, inputAddress, inputEmail;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        // Initialize UI elements
        inputName = findViewById(R.id.etName);
        inputPass = findViewById(R.id.etPass);
        inputAddress = findViewById(R.id.etEmail);
        inputEmail = findViewById(R.id.etAddress);
        Button btnRegister2 = findViewById(R.id.btnRegister2);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Set up a click listener for the Register button
        btnRegister2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call a method to handle the registration process
                registerUser();
            }
        });
    }

    private void registerUser() {
        // Get user input from the EditText fields
        String name = inputName.getText().toString().trim();
        String password = inputPass.getText().toString().trim();
        String email = inputEmail.getText().toString().trim();
        String address = inputAddress.getText().toString().trim();

        // Insert data into the SQLite database
        long result = dbHelper.insertUser(name, password, email, address);

        if (result != -1) {
            // Insertion was successful
            Toast.makeText(RegisterPage.this, "Registration successful", Toast.LENGTH_SHORT).show();
        } else {
            // Insertion failed
            Toast.makeText(RegisterPage.this, "Registration failed", Toast.LENGTH_SHORT).show();
        }

        // Clear the EditText fields
        clearInputFields();
    }

    private void clearInputFields() {
        // Clear the EditText fields
        inputName.setText("");
        inputPass.setText("");
        inputEmail.setText("");
        inputAddress.setText("");
    }
}
