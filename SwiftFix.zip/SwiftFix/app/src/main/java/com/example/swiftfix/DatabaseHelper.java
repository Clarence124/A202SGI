package com.example.swiftfix;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "swiftfix.sqlite";
    private static final String TABLE_NAME = "userregister";
    private static final String COL1 = "name";
    private static final String COL2 = "password";
    private static final String COL3 = "email";
    private static final String COL4 = "address";
    private static final String COL5 = "phonenum";
    private static final String COL6 = "userType";

    private static final String NOTIFICATION_TABLE_NAME = "notifications";
    private static final String NOTIFICATION_COL1 = "appointment_date";
    private static final String NOTIFICATION_COL2 = "appointment_time";
    private static final String NOTIFICATION_COL3 = "appointment_details";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL1 + " TEXT, " +
                COL2 + " TEXT, " +
                COL3 + " TEXT, " +
                COL4 + " TEXT, " +
                COL5 + " TEXT, " +
                COL6 + " TEXT)";
        db.execSQL(createTable);

        // Create the notification table
        String createNotificationTable = "CREATE TABLE " + NOTIFICATION_TABLE_NAME +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOTIFICATION_COL1 + " TEXT, " +
                NOTIFICATION_COL2 + " TEXT, " +
                NOTIFICATION_COL3 + " TEXT)";
        db.execSQL(createNotificationTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public long insertUser(String name, String password, String email, String address, String phonenum, String userType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, name);
        contentValues.put(COL2, password);
        contentValues.put(COL3, email);
        contentValues.put(COL4, address);
        contentValues.put(COL5, phonenum);
        contentValues.put(COL6, userType);
        return db.insert(TABLE_NAME, null, contentValues);
    }

    public boolean checkUserCredentials(String username, String password, String userType) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL1}; // Assuming COL1 is the username column

        String selection = COL1 + " = ? AND " + COL2 + " = ? AND " + COL6 + " = ?";
        String[] selectionArgs = {username, password, userType};

        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);

        int count = cursor.getCount();
        cursor.close();

        return count > 0;
    }

    public long insertNotification(String appointmentDate, String appointmentTime, String appointmentDetails) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NOTIFICATION_COL1, appointmentDate);
        contentValues.put(NOTIFICATION_COL2, appointmentTime);
        contentValues.put(NOTIFICATION_COL3, appointmentDetails);
        return db.insert(NOTIFICATION_TABLE_NAME, null, contentValues);
    }

    public Cursor getAllNotifications() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {NOTIFICATION_COL1, NOTIFICATION_COL2, NOTIFICATION_COL3};
        return db.query(NOTIFICATION_TABLE_NAME, columns, null, null, null, null, null);
    }

    // Add this method to fetch user data by username and userType
    public Cursor getUserData(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL1, COL5, COL3, COL2, COL4}; // Name, Phone, Email, Password, Address
        String selection = COL1 + " = ?";
        String[] selectionArgs = {username};
        return db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
    }

    public boolean updateUserProfile(String username, String name, String phone, String email, String password, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, name);
        contentValues.put(COL5, phone);
        contentValues.put(COL3, email);
        contentValues.put(COL2, password);
        contentValues.put(COL4, address);

        String whereClause = COL1 + " = ?";
        String[] whereArgs = {username};

        int numRowsUpdated = db.update(TABLE_NAME, contentValues, whereClause, whereArgs);

        return numRowsUpdated > 0;
    }

}
