package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class userHomepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_homepage);

        Button notificationBtn = findViewById(R.id.notiBtn);
        notificationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the RegisterActivity when the button is clicked
                Intent intent = new Intent(userHomepage.this, NotificationPage.class);
                startActivity(intent);
            }
        });

        Button profileBtn = findViewById(R.id.btnProfile);
        profileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the RegisterActivity when the button is clicked

                // Inside the userHomepage activity
                String username = getIntent().getStringExtra("username");
                String userType = getIntent().getStringExtra("userType");

                Intent userProfileIntent = new Intent(userHomepage.this, userProfile.class);
                userProfileIntent.putExtra("username", username);
                userProfileIntent.putExtra("userType", userType);
                startActivity(userProfileIntent);
            }
        });

    }
}
