package com.example.swiftfix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FrontInterface extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.front_interface);

            Button registerButton = findViewById(R.id.btnRegister);
            registerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Open the RegisterActivity when the button is clicked
                    Intent intent = new Intent(FrontInterface.this, RegisterPage.class);
                    startActivity(intent);
                }
            });

            Button loginButton = findViewById(R.id.btnLogin);
            loginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Open the RegisterActivity when the button is clicked
                    Intent intent = new Intent(FrontInterface.this, LoginPage.class);
                    startActivity(intent);
                }
            });
        }
    }

