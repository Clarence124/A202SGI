package com.example.swiftfix;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "swiftfix.sqlite";
    private static final String TABLE_NAME = "userregister";
    private static final String COL1 = "name";
    private static final String COL2 = "password";
    private static final String COL3 = "email";
    private static final String COL4 = "address";
    private static final String COL5 = "phonenum";
    private static final String COL6 = "userType";

    private static final String NOTIFICATION_TABLE_NAME = "notifications";
    private static final String NOTIFICATION_COL1 = "appointment_date";
    private static final String NOTIFICATION_COL2 = "appointment_time";
    private static final String NOTIFICATION_COL3 = "appointment_details";

    private static final String SERVICE_PROVIDERS_TABLE_NAME = "service_providers";
    public static final String sProviderCol1 = "name";
    public static final String sProviderCol2 = "phone_number";
    public static final String sProviderCol3 = "email";
    public static final String sProviderCol4 = "date_available";
    public static final String sProviderCol5 = "time_available";
    public static final String sProviderCol6 = "reviews";

    // Pending appointment table variables
    private static final String PENDING_APPOINTMENT_TABLE_NAME = "pending_appointments";
    private static final String COL1_PENDING_APPOINTMENT_ID = "appointment_id";
    private static final String COL2_PENDING_APPOINTMENT = "client_name";
    private static final String COL3_PENDING_APPOINTMENT = "phonenum";
    private static final String COL4_PENDING_APPOINTMENT = "address";
    private static final String COL5_PENDING_APPOINTMENT = "appointment_date";
    private static final String COL6_PENDING_APPOINTMENT = "appointment_time";
    private static final String COL7_PENDING_APPOINTMENT = "selected_service_provider";
    private static final String COL8_PENDING_APPOINTMENT = "reasonforappointment";
    private static final String COL9_PENDING_APPOINTMENT = "servicetype";

    // Confirmed appointment table variables
    private static final String CONFIRMED_APPOINTMENT_TABLE_NAME = "confirmed_appointments";
    private static final String COL1_CONFIRMED_APPOINTMENT_ID = "appointment_id";
    private static final String COL2_CONFIRMED_APPOINTMENT = "client_name";
    private static final String COL3_CONFIRMED_APPOINTMENT = "phonenum";
    private static final String COL4_CONFIRMED_APPOINTMENT = "address";
    private static final String COL5_CONFIRMED_APPOINTMENT = "appointment_date";
    private static final String COL6_CONFIRMED_APPOINTMENT = "appointment_time";
    private static final String COL7_CONFIRMED_APPOINTMENT = "selected_service_provider";
    private static final String COL8_CONFIRMED_APPOINTMENT = "reasonforappointment";
    private static final String COL9_CONFIRMED_APPOINTMENT = "servicetype";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Debugging
        Log.d("DatebaseHelper", "onCreate called. Initial Database version: " + db.getVersion());

        String createTable = "CREATE TABLE " + TABLE_NAME +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL1 + " TEXT, " +
                COL2 + " TEXT, " +
                COL3 + " TEXT, " +
                COL4 + " TEXT, " +
                COL5 + " TEXT, " +
                COL6 + " TEXT)";
        db.execSQL(createTable);

        // Create the notification table
        String createNotificationTable = "CREATE TABLE " + NOTIFICATION_TABLE_NAME +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOTIFICATION_COL1 + " TEXT, " +
                NOTIFICATION_COL2 + " TEXT, " +
                NOTIFICATION_COL3 + " TEXT)";
        db.execSQL(createNotificationTable);

        String createServiceProviderTable = "CREATE TABLE " + SERVICE_PROVIDERS_TABLE_NAME +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                sProviderCol1 + " TEXT, " +
                sProviderCol2 + " TEXT, " +
                sProviderCol3 + " TEXT, " +
                sProviderCol4 + " TEXT, " +
                sProviderCol5 + " TEXT, " +
                sProviderCol6 + " TEXT)";
        db.execSQL(createServiceProviderTable);

        // Create the PENDING appointments table
        String createPendingAppointmentTable = "CREATE TABLE " + PENDING_APPOINTMENT_TABLE_NAME +
                " (" + COL1_PENDING_APPOINTMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL2_PENDING_APPOINTMENT + " TEXT, " +
                COL3_PENDING_APPOINTMENT + " TEXT, " +
                COL4_PENDING_APPOINTMENT + " TEXT, " +
                COL5_PENDING_APPOINTMENT + " TEXT, " +
                COL6_PENDING_APPOINTMENT + " TEXT, " +
                COL7_PENDING_APPOINTMENT + " TEXT, " +
                COL8_PENDING_APPOINTMENT + " TEXT, " +
                COL9_PENDING_APPOINTMENT + " TEXT)";
        db.execSQL(createPendingAppointmentTable);

        // Create the CONFIRMED appointments table
        String createConfirmedAppointmentTable = "CREATE TABLE " + CONFIRMED_APPOINTMENT_TABLE_NAME +
                " (" + COL1_CONFIRMED_APPOINTMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL2_CONFIRMED_APPOINTMENT + " TEXT, " +
                COL3_CONFIRMED_APPOINTMENT + " TEXT, " +
                COL4_CONFIRMED_APPOINTMENT + " TEXT, " +
                COL5_CONFIRMED_APPOINTMENT + " TEXT, " +
                COL6_CONFIRMED_APPOINTMENT + " TEXT, " +
                COL7_CONFIRMED_APPOINTMENT + " TEXT, " +
                COL8_CONFIRMED_APPOINTMENT + " TEXT, " +
                COL9_CONFIRMED_APPOINTMENT + " TEXT)";
        db.execSQL(createConfirmedAppointmentTable);



        // Debugging
        Log.d("DatabaseHelper", "Tables created successfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
        db.execSQL("DROP TABLE IF EXISTS " + PENDING_APPOINTMENT_TABLE_NAME);
        onCreate(db);
        db.execSQL("DROP TABLE IF EXISTS " + CONFIRMED_APPOINTMENT_TABLE_NAME);
        onCreate(db);

    }

    public long insertUser(String name, String password, String email, String address, String phonenum, String userType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, name);
        contentValues.put(COL2, password);
        contentValues.put(COL3, email);
        contentValues.put(COL4, address);
        contentValues.put(COL5, phonenum);
        contentValues.put(COL6, userType);
        return db.insert(TABLE_NAME, null, contentValues);
    }

    public boolean checkUserCredentials(String username, String password, String userType) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL1}; // Assuming COL1 is the username column

        String selection = COL1 + " = ? AND " + COL2 + " = ? AND " + COL6 + " = ?";
        String[] selectionArgs = {username, password, userType};

        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);

        int count = cursor.getCount();
        cursor.close();

        return count > 0;
    }

    public long insertNotification(String appointmentDate, String appointmentTime, String appointmentDetails) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NOTIFICATION_COL1, appointmentDate);
        contentValues.put(NOTIFICATION_COL2, appointmentTime);
        contentValues.put(NOTIFICATION_COL3, appointmentDetails);
        return db.insert(NOTIFICATION_TABLE_NAME, null, contentValues);
    }

    public Cursor getAllNotifications() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {NOTIFICATION_COL1, NOTIFICATION_COL2, NOTIFICATION_COL3};
        return db.query(NOTIFICATION_TABLE_NAME, columns, null, null, null, null, null);
    }

    // Add this method to fetch user data by username and userType
    public Cursor getUserData(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL1, COL5, COL3, COL2, COL4}; // Name, Phone, Email, Password, Address
        String selection = COL1 + " = ?";
        String[] selectionArgs = {username};
        return db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
    }

    public boolean updateUserProfile(String username, String name, String phone, String email, String password, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, name);
        contentValues.put(COL5, phone);
        contentValues.put(COL3, email);
        contentValues.put(COL2, password);
        contentValues.put(COL4, address);

        String whereClause = COL1 + " = ?";
        String[] whereArgs = {username};

        int numRowsUpdated = db.update(TABLE_NAME, contentValues, whereClause, whereArgs);

        return numRowsUpdated > 0;
    }


    // Add this method to fetch service provider data by name
    public Cursor getServiceProviderDataByName(String serviceProviderName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {
                sProviderCol1,
                sProviderCol2,
                sProviderCol3,
                sProviderCol4,
                sProviderCol5,
                sProviderCol6
        };
        String selection = sProviderCol1 + " = ?";
        String[] selectionArgs = {serviceProviderName};
        return db.query(SERVICE_PROVIDERS_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
    }


    // Create new appointment table

    // Appointments

    // For pending appointments
    public long insertPendingAppointment(String clientName, String clientPhone, String clientAddress, String appointmentDate, String appointmentTime, String selectServiceProvider, String appointmentReason, String serviceType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2_PENDING_APPOINTMENT, clientName);
        contentValues.put(COL3_PENDING_APPOINTMENT, clientPhone);
        contentValues.put(COL4_PENDING_APPOINTMENT, clientAddress);
        contentValues.put(COL5_PENDING_APPOINTMENT, appointmentDate);
        contentValues.put(COL6_PENDING_APPOINTMENT, appointmentTime);
        contentValues.put(COL7_PENDING_APPOINTMENT, selectServiceProvider);
        contentValues.put(COL8_PENDING_APPOINTMENT, appointmentReason);
        contentValues.put(COL9_PENDING_APPOINTMENT, serviceType);
        return db.insert(PENDING_APPOINTMENT_TABLE_NAME, null, contentValues);
    }

    public long removePendingAppointment(String pendingAppointmentID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COL1_PENDING_APPOINTMENT_ID + " = ?";
        String[] selectionArgs = {pendingAppointmentID};
        return db.delete(PENDING_APPOINTMENT_TABLE_NAME, selection, selectionArgs);
    }

    // For confirmed & upcoming appointments
    public long insertConfirmedAppointment(String clientName, String clientPhone, String clientAddress, String appointmentDate, String appointmentTime, String selectServiceProvider, String appointmentReason, String serviceType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2_CONFIRMED_APPOINTMENT, clientName);
        contentValues.put(COL3_CONFIRMED_APPOINTMENT, clientPhone);
        contentValues.put(COL4_CONFIRMED_APPOINTMENT, clientAddress);
        contentValues.put(COL5_CONFIRMED_APPOINTMENT, appointmentDate);
        contentValues.put(COL6_CONFIRMED_APPOINTMENT, appointmentTime);
        contentValues.put(COL7_CONFIRMED_APPOINTMENT, selectServiceProvider);
        contentValues.put(COL8_CONFIRMED_APPOINTMENT, appointmentReason);
        contentValues.put(COL9_CONFIRMED_APPOINTMENT, serviceType);
        return db.insert(CONFIRMED_APPOINTMENT_TABLE_NAME, null, contentValues);
    }

    // Retrieving appointment data for service providers sp_appointment view
    public Cursor getAppointmentSPView (String username) {
        // Debugging
        Log.d("DatabaseHelper", "Retrieving appointment data for service provider");

        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL1_PENDING_APPOINTMENT_ID, COL2_PENDING_APPOINTMENT, COL3_PENDING_APPOINTMENT, COL4_PENDING_APPOINTMENT, COL5_PENDING_APPOINTMENT, COL6_PENDING_APPOINTMENT, COL8_PENDING_APPOINTMENT, COL9_PENDING_APPOINTMENT};
        String selection = COL2_PENDING_APPOINTMENT + " = ?";
        String [] selectionArgs = {username};

        return db.query(PENDING_APPOINTMENT_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
    }

    // Retrieving user data for populating the appointment fields
    public Cursor getUserDetailsAppointment(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL1, COL4, COL5};
        String selection = COL1 + " = ?"; // taking username as the condition
        String[] selectionArgs = {username};
        return db.query(TABLE_NAME, columns, selection, selectionArgs, null, null,null);
    }

    // Retrieving upcoming appointment data
    public Cursor getAppointment(){
        // Debugging
        Log.d("DatabaseHelper", "Retrieving appointment data from database");

        SQLiteDatabase DB = this.getWritableDatabase();
        String[] columns = {COL5_CONFIRMED_APPOINTMENT, COL6_CONFIRMED_APPOINTMENT, COL7_CONFIRMED_APPOINTMENT}; // Querying the service provider name, date & time of appointment
        return DB.query(CONFIRMED_APPOINTMENT_TABLE_NAME, columns, null, null, null , null, null);
    }

    // Retrieving past appointment data
    public Cursor getOldAppointment() {
        //Debugging
        Log.d("DatabaseHelper", "Retrieving old appointments from database");

        SQLiteDatabase DB = this.getWritableDatabase();
        String[] columns = {COL7_CONFIRMED_APPOINTMENT, COL8_CONFIRMED_APPOINTMENT}; // Querying the service provider name, date & time of appointment
        return DB.query(CONFIRMED_APPOINTMENT_TABLE_NAME, columns, null, null, null , null, null);
    }

    // For client appointment page - autocomplete field for service provider names
    public ArrayList<String> getServiceProviders() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> allSP = new ArrayList<>();
        String[] column = {COL1};
        String selection = COL6 + " = ?";
        String[] selectionArgs = {"Service Provider"};
        Cursor cursor = db.query(TABLE_NAME, column, selection,selectionArgs, null, null, null);

        // Adding the service providers' names into the ArrayList object
        if (cursor != null) {
            int columnIndex = cursor.getColumnIndex(COL2);
            if (columnIndex != -1 && cursor.moveToFirst()) {
                do {
                    allSP.add(cursor.getString(columnIndex));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        return allSP;
    }


}

