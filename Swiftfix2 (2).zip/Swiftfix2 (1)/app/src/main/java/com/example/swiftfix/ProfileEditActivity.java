package com.example.swiftfix;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileEditActivity extends AppCompatActivity {

    EditText editName, editPhone, editEmail, editPw;
    Button Edit;
    Database DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_edit);

        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        editEmail = findViewById(R.id.editEmail);
        editPw = findViewById(R.id.editPw);

        Edit = findViewById(R.id.ebutton);
        DB = new Database(this);


        Edit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String nameTXT = editName.getText().toString();
                String phoneTXT = editPhone.getText().toString();
                String emailTXT = editEmail.getText().toString();
                String pwTXT = editPw.getText().toString();

                Boolean checkeditdata = DB.edituserdata(nameTXT, phoneTXT, emailTXT, pwTXT);
                if (checkeditdata == true)
                    Toast.makeText(ProfileEditActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(ProfileEditActivity.this, "Failed to Updated Profile", Toast.LENGTH_SHORT).show();

            }


        });
    }
}